# LogLine v1.0 — Full Spec Bundle

This bundle includes a **full edition** of the 20-section spec (with warmth lines), per-section files, registries,
sample grammar/allowlist, a minimal OpenAPI, and a Node script to generate deterministic test vectors.

## Files
- `spec/SPEC_FULL.md` — Epigraph + part taglines + 20 expanded sections (each with 7 items, ~250–400 words).
- `spec/sections/` — one file per section for granular edits or PR reviews.
- `registries/registries.md` — initial context, chain, algorithm, and error registries.
- `grammars/default@1.1.yaml` — deterministic subset YAML example.
- `allowlists/baseline.json` — deny-by-default allowlist with ceilings.
- `api/logline-httpd-openapi.yaml` — minimal OpenAPI stub for `/v1` endpoints.
- `scripts/gen_vectors.mjs` + `vectors/test_vectors_input.json` — generate `.ndjson` vectors (hash/sign/tie/merkle).
- `examples/dri_example.json` — end-to-end micro example payload (E1).

## Usage
```bash
# (Optional) Generate test vectors (requires Node)
npm i blake3 @noble/ed25519
node scripts/gen_vectors.mjs
cat vectors/logline_test_vectors.ndjson
```

## Notes
- The Ed25519 key embedded in the generator is **for testing only**.
- The spec uses **JSON✯Atomic** canonicalization, **BLAKE3** hashing with domain separation, and **Ed25519** signatures.
- Warmth lines (epigraph + taglines) are included, and the **Listening Pledge** appears in §1.1 item (6).

Generated: 2025-11-16T20:30:08.779440Z