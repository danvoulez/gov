# Deploy — Vercel

Importe o repo; Node 20; `next build`; aponte domínios; confira /provas-ao-vivo.
