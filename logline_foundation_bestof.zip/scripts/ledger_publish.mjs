#!/usr/bin/env node
import fs from 'node:fs'
console.log('ledger_publish stub — substitua pelo script completo quando for publicar spans.') 
process.exit(0)
