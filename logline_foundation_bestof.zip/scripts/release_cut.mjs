#!/usr/bin/env node
import fs from 'node:fs'
import path from 'node:path'
const stamp = new Date().toISOString().replace(/[-:]/g,'').slice(0,15)
const dir = path.join('public','releases',stamp)
fs.mkdirSync(dir, { recursive: true })
fs.writeFileSync(path.join(dir,'manifest.json'), JSON.stringify({stamp, files:[]}, null, 2))
fs.writeFileSync(path.join('public','releases','latest.json'), JSON.stringify({stamp, manifest:'/releases/'+stamp+'/manifest.json'}, null, 2))
console.log('release cut (stub):', stamp)
