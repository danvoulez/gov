# DNS Guide

Configure A/AAAA/CNAME para Vercel; MX/SPF/DKIM/DMARC para email.
